<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Services\Aquarium\AquariumService;
use Illuminate\Http\Request;
use PhpMqtt\Client\Facades\MQTT;
use Illuminate\Support\Facades\Mail;

class AquariumApiController extends Controller
{
    protected $aquariumService;
    public function __construct(AquariumService $aquariumService)
    {
        $this->aquariumService = $aquariumService;
    }
}
