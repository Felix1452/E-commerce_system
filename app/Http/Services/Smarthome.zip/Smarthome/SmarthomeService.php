<?php

namespace App\Http\Services\Smarthome;
use App\Models\Dht22;

class SmarthomeService
{
    public function create($topic, $temperature, $humidity){
        Dht22::create([
            'topic'=>(string)$topic,
            'temperatute'=>(double)$temperature,
            'humidity'=>(double)$humidity
        ]);
    }
}
